<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="enviar_info.php" method="post"> 
    <input class="field" id="Name" name="Name" type="text" placeholder="Nombre"></input>
    <input class="field" id="Email" name="Email" type="text" placeholder="Correo Electronico"></input>
    <input class="field" id="Pasw" name="Pasw" type="password" placeholder="Contraseña"></input>
    <input type="submit" value="Continuar" class="Signup_button" name="send">
</form>
</body>
</html>