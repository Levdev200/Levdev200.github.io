<?php
$user = "root";
$pass = "";
$host = "localhost";

$connection = mysqli_connect($host, $user, $pass); 

$datab = "closebd";
$db = mysqli_select_db($connection,$datab);

$consulta = "SELECT * FROM usuarios";
$result = mysqli_query($connection,$consulta);
if(!$result) 
{
    echo "No se ha podido realizar la consulta";
}

echo "<table>";
echo "<tr>";
echo "<th><h1>ID</th></h1>";
echo "<th><h1>Nombre</th></h1>";
echo "</tr>";

while ($colum = mysqli_fetch_array($result))
 {
    echo "<tr>";
    echo "<td><h2>" . $colum['ID']. "</td></h2>";
    echo "<td><h2>" . $colum['Nombre'] . "</td></h2>";
    echo "</tr>";
}
echo "</table>";