<?php
include 'conexionbd.php';



if(isset($_POST['send'])) {
    if (
        strlen($_POST['Name']) >=1 &&
        strlen($_POST['Email']) >=1 &&
        strlen($_POST['Pasw']) >=1
    ) {
        $Name = trim($_POST['Name']);
        $Email = trim($_POST['Email']);
        $Pasw = trim($_POST['Pasw']);
        $insert_data = "INSERT INTO usuarios(Nombre, Correo, Contraseña) VALUES('$Name','$Email','$Pasw')";
        $result = mysqli_query($conection,$insert_data);
        if ($result) {
            echo("Los datos se enviaron correctamente");
        } else {
            echo("Hubo un error al enviar los datos");
        }
     }

} else {
    echo("error");
}

?>