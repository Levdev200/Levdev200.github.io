<?php
// setid();
error_reporting(0);

include 'verify_id.php';
// print($GLOBALS["id"]);
$newid = $GLOBALS["id"];

// function setid() {

//     // $GLOBALS["os"] =& $GLOBALS["id_num"];
//     global $id;

//     echo($id);



// }
