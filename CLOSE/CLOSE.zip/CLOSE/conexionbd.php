<?php 

$host = "localhost";
$user = "root";
$pass = "";
$bd = "closebd";
    
$conection = mysqli_connect($host,$user,$pass,$bd);
mysqli_select_db($conection,$bd);

?>